/**
 * .channels - list / manage the WhatsApp Channels the bot account owns or administers.
 *
 * The list comes LIVE from WhatsApp (the account's own subscribed-channels query,
 * with the role of this account in each). Owner/admin channels are also written to
 * a separate file: database/my_admin_channels.json  (send it with `.channels export`).
 * If the live query fails, it falls back to the tracked list (ids.json, observed
 * posts, `.channels add`) and verifies each one with newsletterMetadata.
 */
const config = require('../../config');
const hub = require('../../utils/channelHub');

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const fmtDate = (s) => { try { return new Date(s * 1000).toISOString().slice(0, 10); } catch { return '?'; } };

const chunkText = (lines, max = 3500) => {
  const out = []; let cur = '';
  for (const l of lines) { if ((cur + '\n' + l).length > max && cur) { out.push(cur); cur = l; } else cur = cur ? `${cur}\n${l}` : l; }
  if (cur) out.push(cur);
  return out;
};

const describe = (rec, sock, i) => {
  const role = hub.roleFor(rec, sock);
  const badge = hub.isAdminFor(rec, sock) ? (role === 'OWNER' ? '👑 OWNER' : '🛡️ ADMIN') : (role ? `👤 ${role}` : '❔ role unknown');
  const lines = [`*${i}. ${rec.name || 'Unnamed channel'}*  ${badge}`, `🆔 \`${rec.jid}\``];
  const link = hub.channelLink(rec);
  lines.push(link ? `🔗 ${link}` : '🔗 (no invite link available)');
  const extra = [];
  if (rec.subscribers != null) extra.push(`👥 ${rec.subscribers.toLocaleString('en-US')} followers`);
  if (rec.verification && String(rec.verification).toUpperCase() === 'VERIFIED') extra.push('✔️ verified');
  if (rec.creationTime) extra.push(`📅 created ${fmtDate(rec.creationTime)}`);
  if (extra.length) lines.push(extra.join(' • '));
  return lines.join('\n');
};

module.exports = {
  name: 'channels',
  aliases: ['mychannels', 'chlist'],
  category: 'dev',
  description: 'List WhatsApp Channels you own/admin (verified with WhatsApp) and manage the channel list',
  usage: `${config.prefix}channels [-a -s [sync|links] | all | sync | syncall | sessions | export | add <jid|link> | remove <jid> | refresh | log | logdest <bot|jid|default> | status]`,
  ownerOnly: true,

  // called once per connected session by handler.initializePlugins(): starts the deletion watcher
  async init(sock) { try { hub.ensurePoller(sock); } catch { /* never block startup */ } },

  async execute(sock, msg, args, extra) {
    const { reply, react } = extra;
    if (!extra.isOwner && !extra.isSudo) return reply('🔒 Owner only.');
    const low = args.map((a) => String(a).toLowerCase());
    const allSessions = low.includes('--all-sessions') || low.includes('-as') || low.includes('-sa') || (low.includes('-a') && low.includes('-s'));
    if (allSessions) args = args.filter((a) => !String(a).startsWith('-')); // keep the words (sync/links/ids...), drop the flags
    const sub = (args[0] || '').toLowerCase();
    try {
      hub.registerSock(sock);

      if (sub === 'add') {
        const input = args[1];
        if (!input) return reply(`❌ Usage: ${config.prefix}channels add <channel link | 1203...@newsletter>`);
        await react('⏳');
        let jid;
        const link = hub.parseChannelLink(input);
        if (link) jid = (await hub.resolveInvite(sock, link.code)).rec.jid;
        else jid = /@newsletter$/.test(input) ? input : (/^\d{10,}$/.test(input) ? `${input}@newsletter` : null);
        if (!jid) return reply('❌ Give a channel link (https://whatsapp.com/channel/...) or a JID ending in @newsletter.');
        const v = await hub.verifyChannel(sock, jid, { force: true });
        if (!v.ok) { await react('❌'); return reply(`❌ Added to the list but WhatsApp could not verify it: ${v.error}`); }
        await react('✅');
        return reply(`✅ Tracked.\n\n${describe(v.rec, sock, 1)}\n\n${hub.isAdminFor(v.rec, sock) ? 'You are admin here: .cforward will post to it and deleted posts will be logged.' : '⚠️ This account is NOT admin/owner of this channel, so it will not be used for posting or deletion logs.'}`);
      }

      if (sub === 'remove' || sub === 'rm' || sub === 'del') {
        const jid = args[1];
        if (!jid) return reply(`❌ Usage: ${config.prefix}channels remove <jid>`);
        const ok = hub.removeChannel(/@/.test(jid) ? jid : `${jid}@newsletter`);
        return reply(ok ? '✅ Removed from the tracked list (cached posts deleted). It may be re-added automatically if it is in the remote ids.json.' : '⚠️ That channel was not in the tracked list.');
      }

      if (sub === 'logdest') {
        const v = (args[1] || '').toLowerCase();
        const db = extra.database || sock.sessionDb || require('../../database');
        if (!v) { return reply(`Current channel log destination: ${db.getGlobalSetting('channelLogDest') || '(default: same as antidelete / this bot chat)'}\nUsage: ${config.prefix}channels logdest <bot|jid|default>`); }
        if (v === 'default') { db.setGlobalSetting('channelLogDest', null); return reply('✅ Channel deletion logs now follow your antidelete destination (private chat if it is set to "chat").'); }
        const dest = v === 'bot' ? 'bot' : (args[1].includes('@') ? args[1] : `${args[1].replace(/\D/g, '')}@s.whatsapp.net`);
        db.setGlobalSetting('channelLogDest', dest);
        return reply(`✅ Channel deletion logs will be sent to: ${dest}`);
      }

      if (sub === 'log') {
        const st = hub.status();
        if (!st.deleteLog.length) return reply('📭 No channel post deletions have been logged yet.');
        return reply('*🗑️ Recent channel deletions*\n\n' + st.deleteLog.slice().reverse().map((d, i) => `${i + 1}. ${d.name || d.jid} • post ${d.serverId}${d.cached ? '' : ' (not cached)'}\n   ${new Date(d.at).toISOString().replace('T', ' ').slice(0, 16)} UTC${d.snippet ? `\n   “${d.snippet}”` : ''}`).join('\n'));
      }

      if (sub === 'status') {
        const st = hub.status();
        return reply(`*📡 Channel system*\nTracked channels: ${st.channels} (admin/owner: ${st.admin})\nCached posts: ${st.cachedPosts}\nDeletion watcher: ${st.polling ? `on (every ${Math.round(st.pollMs / 60000)} min)` : 'off'}\nLast check: ${st.lastPoll.at ? new Date(st.lastPoll.at).toISOString().replace('T', ' ').slice(0, 19) + ' UTC' : 'never'} (${st.lastPoll.channels} channels, ${st.lastPoll.newPosts} new posts, ${st.lastPoll.deletions} deletions)`);
      }

      // ---- ALL SESSIONS overview: every connected session's owner/admin channels + followers (main owner number only) ----
      if (allSessions) {
        if (!hub.isAllSessionsUser(extra)) return reply('⛔ *Restricted*\nThe all-sessions view (-a -s) can only be used by the main owner number.');
        await react('⏳');
        await reply('🔄 Collecting channels + followers from every connected session (one by one, please wait)...');
        const force = args.some((a) => ['sync', 'refresh'].includes(String(a).toLowerCase()));
        const showLinks = args.some((a) => String(a).toLowerCase() === 'links');
        const data = await hub.collectAllSessions(sock, { force });
        if (!data.rows.length) { await react('❌'); return reply(`❌ No session could be read.${data.problems.length ? '\n' + data.problems.slice(0, 8).map((p) => `• +${p.account}: ${p.error}`).join('\n') : ''}`); }
        const n = (v) => (v == null ? '?' : Number(v).toLocaleString('en-US'));
        const lines = [`*📡 ALL SESSIONS — owner/admin channels*`, `Sessions: ${data.rows.length} • Channels (unique): ${data.unique} • 👥 Total followers: ${n(data.totalFollowers)}${data.noCount ? ` (+${data.noCount} channel(s) without a count)` : ''}`, `💾 Saved: database/my_admin_channels.json`, ''];
        for (const r of data.rows) {
          lines.push(`📱 *+${r.account}* — follows ${r.followed} • 👑 ${r.owners} owner • 🛡️ ${r.admins} admin`);
          if (!r.channels.length) lines.push('   (no owner/admin channel)');
          r.channels.forEach((c, i) => {
            lines.push(`${i + 1}. ${c.role === 'OWNER' ? '👑' : '🛡️'} *${c.name || 'Unnamed'}* — 👥 ${n(c.followers)}`);
            lines.push(`   🆔 \`${c.jid}\``);
            if (showLinks && c.link) lines.push(`   🔗 ${c.link}`);
          });
          lines.push('');
        }
        if (data.problems.length) lines.push(`⚠️ *Not read (${data.problems.length}):*`, ...data.problems.slice(0, 10).map((p) => `• +${p.account}: ${p.error}`));
        for (const p of chunkText(lines)) await reply(p);
        await react('✅');
        return;
      }

      if (sub === 'sessions') {
        const rows = hub.savedAccounts();
        if (!rows.length) return reply(`📭 Nothing saved yet. Run ${config.prefix}channels sync (this session) or ${config.prefix}channels syncall (all connected sessions).`);
        const lines = ['*🗂️ Saved: which session administers which channels*', ''];
        for (const r of rows) {
          const ago = r.syncedAt ? Math.round((Date.now() - Date.parse(r.syncedAt)) / 60000) : '?';
          lines.push(`📱 *+${r.account}* — ${r.count} channel(s) • synced ${ago} min ago`);
          for (const c of r.channels.slice(0, 15)) lines.push(`   ${c.role === 'OWNER' ? '👑' : '🛡️'} ${c.name || c.jid}`);
          if (r.channels.length > 15) lines.push(`   …and ${r.channels.length - 15} more`);
          lines.push('');
        }
        for (const p of chunkText(lines)) await reply(p);
        return;
      }

      if (sub === 'syncall') {
        await react('⏳');
        await reply('🔄 Syncing every connected session with WhatsApp (one by one, this takes a moment)...');
        const r = await hub.syncAllSessions({ force: true });
        const lines = [`*🔄 Sync finished* — ${r.ok}/${r.total} session(s) updated`];
        for (const x of r.rows) lines.push(`• +${x.account}: follows ${x.followed}, owner/admin of ${x.admin}`);
        if (r.failed.length) lines.push('', `⚠️ Failed (${r.failed.length}):`, ...r.failed.slice(0, 10).map((f) => `• +${f.account}: ${f.error}`));
        lines.push('', `💾 Saved in database/my_admin_channels.json — see ${config.prefix}channels sessions`);
        await react('✅');
        for (const p of chunkText(lines)) await reply(p);
        return;
      }

      if (sub === 'export' || sub === 'file') {
        let obj = hub.readAdminFile();
        if (!obj.accounts || !Object.keys(obj.accounts).length) {
          await reply('⏳ No saved file yet - syncing from WhatsApp first...');
          const r = await hub.syncMyChannels(sock, { force: true });
          if (!r.ok) return reply(`❌ Live sync failed: ${r.error}`);
          obj = hub.readAdminFile();
        }
        await sock.sendMessage(extra.from, { document: Buffer.from(JSON.stringify(obj, null, 2)), mimetype: 'application/json', fileName: 'my_admin_channels.json' }, { quoted: msg });
        return;
      }

      // ---- list (default / all / sync / refresh) ----
      const showAll = sub === 'all';
      const force = sub === 'refresh' || sub === 'sync';
      await react('⏳');

      // 1) preferred: live list from WhatsApp itself
      const live = await hub.syncMyChannels(sock, { force });
      if (live.ok) {
        await hub.fillFollowers(sock, live.admin); // follower counts the list did not carry (paced, cached 30 min)
        const rows = (showAll ? live.all : live.admin).slice();
        const owners = live.admin.filter((r) => hub.roleFor(r, sock) === 'OWNER').length;
        const tf = live.admin.reduce((a, r) => a + (Number(r.subscribers) || 0), 0);
        const head = `📡 Live from WhatsApp: ${live.total} channel(s) followed • 👑 ${owners} owner • 🛡️ ${live.admin.length - owners} admin • 👥 ${tf.toLocaleString('en-US')} followers in your channels${live.noRole ? ` • ❔ ${live.noRole} role unknown` : ''}\n💾 Owner/admin list saved: database/my_admin_channels.json ${live.saved ? '✅' : '⚠️ (write failed)'}  — send it with ${config.prefix}channels export`;
        if (!rows.length) { await react('❌'); return reply(`${head}\n\n📭 No channel where this account is owner/admin.\nUse ${config.prefix}channels all to see every followed channel.`); }
        rows.sort((a, b) => (hub.isAdminFor(b, sock) - hub.isAdminFor(a, sock)) || String(a.name).localeCompare(String(b.name)));
        const blocks = rows.map((r, i) => describe(r, sock, i + 1));
        const parts = chunkText([`*📢 ${showAll ? 'All my channels' : 'My channels (owner/admin)'}* — ${rows.length}`, '', ...blocks.flatMap((b) => [b, ''])]);
        await reply(head);
        for (const p of parts) await reply(p);
        await react('✅');
        return;
      }

      // 2) fallback: tracked list, each verified with WhatsApp
      await reply(`⚠️ Live channel list failed (${live.error}).\nFalling back to the tracked list...`);
      try { for (const e of require('../../utils/channelManager').getNewsletters()) hub.ensureChannel(e.id, 'managed'); } catch { /* optional */ }
      const all = hub.listChannels();
      if (!all.length) {
        await react('❌');
        return reply('📭 No channels known yet.\n\nBaileys cannot list your channels by itself. Add one with:\n' + `${config.prefix}channels add <channel link or 1203...@newsletter>\n\n(The bot also picks up channels it receives posts from, and the ones in your remote ids.json.)`);
      }
      if (all.length > 3) await reply(`🔎 Verifying ${all.length} channel(s) with WhatsApp...`);
      const failed = [];
      for (const rec of all.slice(0, 60)) {
        const v = await hub.verifyChannel(sock, rec.jid, { force });
        if (!v.ok) failed.push(`• ${rec.name || rec.jid}: ${v.error}`);
        if (!v.cached) await sleep(350);
      }
      const rows = all.filter((r) => showAll || hub.isAdminFor(r, sock));
      if (!rows.length) {
        await react('❌');
        return reply(`📭 None of the ${all.length} known channel(s) is owned/administered by this account.\nUse ${config.prefix}channels all to see them anyway.${failed.length ? `\n\n⚠️ Could not verify:\n${failed.join('\n')}` : ''}`);
      }
      rows.sort((a, b) => (hub.isAdminFor(b, sock) - hub.isAdminFor(a, sock)) || String(a.name).localeCompare(String(b.name)));
      const header = `*📢 ${showAll ? 'Known channels' : 'My channels (owner/admin)'}* — ${rows.length}`;
      const blocks = rows.map((r, i) => describe(r, sock, i + 1));
      const parts = chunkText([header, '', ...blocks.flatMap((b) => [b, ''])]);
      if (failed.length) parts.push(`⚠️ *Could not verify (${failed.length}):*\n${failed.slice(0, 10).join('\n')}`);
      for (const p of parts) await reply(p);
      await react('✅');
    } catch (e) {
      console.error('[channels]', e);
      await reply(`❌ ${e.message}`);
      await react('❌');
    }
  }
};
