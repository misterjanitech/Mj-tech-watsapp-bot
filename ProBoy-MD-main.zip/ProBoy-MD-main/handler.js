/**
 * Message Handler - Processes incoming messages and executes commands
 * + Integrated Button Support (FIXED for quick_reply)
 * + PERFORMANCE FIX: removed config reload on every message
 *
 * ============================================================================
 * v2 CHANGELOG (this revision)
 * ============================================================================
 * FIXED:
 *  - antilink was defined but never actually invoked in handleMessage (only
 *    called from a racy fire-and-forget spot in proboy.js, after the
 *    message had already been fully processed). Now invoked synchronously,
 *    first, exactly like every other anti-feature. See utils/antiSystem.js.
 *  - anticall read a static config value that no command could ever change
 *    at runtime, so it was permanently a no-op. Now backed by a DB global
 *    setting toggled with `.anticall on|off`. See utils/antiSystem.js.
 *
 * ADDED (new, non-hardcoded, fully dynamic):
 *  - utils/channelManager.js: loads managed newsletter/group/user JIDs from
 *    a remote JSON file (https://proboy.vercel.app/bot/ids.json). No JIDs
 *    are ever hardcoded in this file.
 *  - utils/reactionManager.js: consolidates the auto-react logic that used
 *    to be duplicated in both proboy.js and here (risk of double-firing)
 *    into one place, plus the new permanent managed-channel auto-react.
 *  - utils/buttonManager.js: universal button framework — buttons can run
 *    an existing command OR a fully custom registered script.
 *  - utils/automationEngine.js: generic IF/THEN rule engine, foundation for
 *    future channel/status automation commands.
 *
 * Every original feature/function below is unchanged in behavior unless
 * explicitly noted above.
 * ============================================================================
 */

const config = require('./config');          // ✅ loaded once at startup
const defaultDatabase = require('./database');
const { loadCommands } = require('./utils/commandLoader');
const { addMessage } = require('./utils/groupstats');
const { jidDecode, jidEncode } = require('@whiskeysockets/baileys');
const fs = require('fs');
const path = require('path');
const axios = require('axios');

const channelManager = require('./utils/channelManager');
const reactionManager = require('./utils/reactionManager');
const antiSystem = require('./utils/antiSystem');
const buttonManager = require('./utils/buttonManager');
const automationEngine = require('./utils/automationEngine');
const logger = require('./utils/logger');

const memoryGuard = require('./utils/memoryGuard');
const channelHub = require('./utils/channelHub');

// Group metadata cache to prevent rate limiting.
// STABILITY FIX: this used to be an unbounded Map (every group seen by every
// session, full participant lists, kept forever). It is now bounded (LRU) and
// entries older than STALE_TTL are dropped. CACHE_TTL is unchanged (freshness
// window); STALE_TTL only bounds how long an entry may be used as a fallback
// when the live query fails.
const groupMetadataCache = new memoryGuard.BoundedMap(150, { ttlMs: 10 * 60 * 1000 });
const CACHE_TTL = 60000; // 1 minute cache

// Coalesce concurrent live metadata requests for the same group (N sessions
// receiving the same group message used to fire N identical IQ queries).
const inflightMetadata = new Map(); // groupId -> Promise<metadata|null>

// Load all commands
const commands = loadCommands();
const pluginInitDone = new WeakMap(); // sock -> Set(commandName)

const reloadCommands = () => {
  const fresh = loadCommands({ fresh: true });
  commands.clear();
  for (const [key, value] of fresh.entries()) commands.set(key, value);
  return commands;
};

const initializePlugins = async (sock) => {
  if (!sock) return;
  let done = pluginInitDone.get(sock);
  if (!done) {
    done = new Set();
    pluginInitDone.set(sock, done);

    // One-time-per-socket boot of the new dynamic systems. channelManager's
    // scheduler is globally idempotent (safe even with multiple sessions).
    channelManager.start();
    reactionManager.autoJoinManagedNewsletters(sock).catch(err => logger.error('CHANNEL', 'Auto-join failed:', err));
  }

  for (const command of new Set(commands.values())) {
    if (!command?.name || done.has(command.name)) continue;
    if (typeof command.init !== 'function') continue;
    try {
      await command.init(sock);
      done.add(command.name);
    } catch (error) {
      console.error(`Error in init of ${command.name}:`, error?.message || error);
    }
  }
};

// Unwrap WhatsApp containers (ephemeral, view once, etc.)
const getMessageContent = (msg) => {
  if (!msg || !msg.message) return null;

  let m = msg.message;

  // Common wrappers in modern WhatsApp
  if (m.ephemeralMessage) m = m.ephemeralMessage.message;
  if (m.viewOnceMessageV2) m = m.viewOnceMessageV2.message;
  if (m.viewOnceMessage) m = m.viewOnceMessage.message;
  if (m.documentWithCaptionMessage) m = m.documentWithCaptionMessage.message;

  return m;
};

// Cached group metadata getter with rate limit handling (for non-admin checks)
const getCachedGroupMetadata = async (sock, groupId) => {
  try {
    if (!groupId || !groupId.endsWith('@g.us')) {
      return null;
    }

    const cached = groupMetadataCache.get(groupId);
    if (cached && Date.now() - cached.timestamp < CACHE_TTL) {
      return cached.data;
    }

    const metadata = await sock.groupMetadata(groupId);
    groupMetadataCache.set(groupId, {
      data: metadata,
      timestamp: Date.now()
    });

    return metadata;
  } catch (error) {
    if (error.message && (
      error.message.includes('forbidden') ||
      error.message.includes('403') ||
      error.statusCode === 403 ||
      error.output?.statusCode === 403 ||
      error.data === 403
    )) {
      groupMetadataCache.set(groupId, {
        data: null,
        timestamp: Date.now()
      });
      return null;
    }

    if (error.message && error.message.includes('rate-overlimit')) {
      const cached = groupMetadataCache.get(groupId);
      if (cached) return cached.data;
      return null;
    }

    const cached = groupMetadataCache.get(groupId);
    if (cached) return cached.data;

    return null;
  }
};

// Live group metadata getter - for admin checks.
// maxAgeMs = 0 (default) keeps the original contract: always a fresh query.
// A positive maxAgeMs accepts a cached copy that young. Concurrent fresh
// queries for the same group are coalesced into one request.
const getLiveGroupMetadata = async (sock, groupId, maxAgeMs = 0) => {
  if (maxAgeMs > 0) {
    const cached = groupMetadataCache.get(groupId);
    if (cached && cached.data && Date.now() - cached.timestamp < maxAgeMs) return cached.data;
  }
  const pending = inflightMetadata.get(groupId);
  if (pending) return pending;

  const run = (async () => {
    try {
      const metadata = await sock.groupMetadata(groupId);
      groupMetadataCache.set(groupId, {
        data: metadata,
        timestamp: Date.now()
      });
      return metadata;
    } catch (error) {
      const cached = groupMetadataCache.get(groupId);
      if (cached) return cached.data;
      return null;
    } finally {
      inflightMetadata.delete(groupId);
    }
  })();
  inflightMetadata.set(groupId, run);
  return run;
};

// Alias for backward compatibility (non-admin features use cached)
const getGroupMetadata = getCachedGroupMetadata;

// Helper functions
const normalizeEntryNumber = (val) => String(val || '').replace(/\D/g, '');

const isOwner = (sender) => {
  if (!sender) return false;

  const ownerNumbers = Array.isArray(config.ownerNumber) ? config.ownerNumber : [];
  const ownerJids = Array.isArray(config.ownerJids) ? config.ownerJids : [];
  const senderNumber = normalizeEntryNumber(normalizeJidWithLid(sender));
  if (senderNumber && ownerNumbers.map(normalizeEntryNumber).includes(senderNumber)) return true;
  const entries = [
    ...ownerNumbers.map(n => `${normalizeEntryNumber(n)}@s.whatsapp.net`).filter(v => !v.startsWith('@')),
    ...ownerJids
  ];
  if (!entries.length) return false;

  const { ids, numbers } = getComparableContext(sender);
  for (const entry of entries) {
    const s = String(entry || '').trim();
    if (!s) continue;
    if (s.includes('@')) {
      const ctx = getComparableContext(s);
      for (const id of ctx.ids) if (ids.has(id)) return true;
      for (const n of ctx.numbers) if (numbers.has(n)) return true;
      continue;
    }
    const n = normalizeEntryNumber(s);
    if (n && numbers.has(n)) return true;
  }
  return false;
};

const getDb = (sock) => sock?.sessionDb || defaultDatabase;

const getComparableContext = (jid) => {
  const ids = new Set([
    ...buildComparableIds(jid),
    ...buildComparableIds(normalizeJidWithLid(jid))
  ].filter(Boolean));
  const numbers = new Set(Array.from(ids).map(normalizeJid).map(normalizeEntryNumber).filter(Boolean));
  return { ids, numbers };
};

const isSudo = (sock, sender) => {
  if (!sender) return false;
  const db = getDb(sock);
  const cfgNums = Array.isArray(config.sudoNumbers) ? config.sudoNumbers : [];
  const cfgJids = Array.isArray(config.sudoJids) ? config.sudoJids : [];
  const dbList = db.getGlobalSetting('sudoUsers');
  const dynamic = Array.isArray(dbList) ? dbList : [];
  const entries = [...cfgNums, ...cfgJids, ...dynamic];

  if (!entries.length) return false;
  const senderNumber = normalizeEntryNumber(normalizeJidWithLid(sender));
  if (senderNumber && entries.map(normalizeEntryNumber).includes(senderNumber)) return true;
  const { ids, numbers } = getComparableContext(sender);

  for (const entry of entries) {
    const s = String(entry || '').trim();
    if (!s) continue;
    if (s.includes('@')) {
      const ctx = getComparableContext(s);
      for (const id of ctx.ids) if (ids.has(id)) return true;
      for (const n of ctx.numbers) if (numbers.has(n)) return true;
      continue;
    }
    const n = normalizeEntryNumber(s);
    if (n && numbers.has(n)) return true;
  }
  return false;
};

const isPrivileged = (sock, sender) => isOwner(sender) || isSudo(sock, sender);

const isBannedUser = (sock, sender) => {
  if (!sender) return false;
  if (isPrivileged(sock, sender)) return false;
  const db = getDb(sock);
  const list = db.getGlobalSetting('bannedUsers');
  const banned = Array.isArray(list) ? list : [];
  if (!banned.length) return false;

  const { ids, numbers } = getComparableContext(sender);
  for (const entry of banned) {
    const s = String(entry || '').trim();
    if (!s) continue;
    if (s.includes('@')) {
      const ctx = getComparableContext(s);
      for (const id of ctx.ids) if (ids.has(id)) return true;
      for (const n of ctx.numbers) if (numbers.has(n)) return true;
      continue;
    }
    const n = normalizeEntryNumber(s);
    if (n && numbers.has(n)) return true;
  }
  return false;
};

const isMod = (sock, sender) => {
  const number = normalizeEntryNumber(normalizeJidWithLid(sender));
  return getDb(sock).isModerator(number);
};

const getDisplaySender = (sender) => {
  const normalized = normalizeJidWithLid(sender);
  const number = normalizeEntryNumber(normalized);
  return number || String(sender || '');
};

// Backwards compatibility for code paths that haven't been migrated yet
const database = defaultDatabase;

// LID mapping cache.
// STABILITY FIX: was an unbounded Map that also cached "not found" forever (so
// a mapping learned later was never seen until restart). Now bounded; misses
// are re-checked after 5 minutes, hits are kept for 1 hour.
const lidMappingCache = new memoryGuard.BoundedMap(5000);
const LID_HIT_TTL_MS = 60 * 60 * 1000;
const LID_MISS_TTL_MS = 5 * 60 * 1000;
let authDirCache = { expiresAt: 0, dirs: [] };

const normalizeJid = (jid) => {
  if (!jid) return null;
  if (typeof jid !== 'string') return null;

  if (jid.includes(':')) {
    return jid.split(':')[0];
  }
  if (jid.includes('@')) {
    return jid.split('@')[0];
  }
  return jid;
};

const getAuthDirectories = () => {
  const now = Date.now();
  if (authDirCache.expiresAt > now && authDirCache.dirs.length) return authDirCache.dirs;

  const dirs = [];
  const primarySession = path.join(__dirname, config.sessionName || 'session');
  if (fs.existsSync(primarySession)) dirs.push(primarySession);

  const sessionsRoot = path.join(__dirname, 'sessions');
  if (fs.existsSync(sessionsRoot)) {
    try {
      for (const entry of fs.readdirSync(sessionsRoot, { withFileTypes: true })) {
        if (entry.isDirectory() && entry.name.startsWith('auth-')) {
          dirs.push(path.join(sessionsRoot, entry.name));
        }
      }
    } catch {}
  }

  authDirCache = {
    expiresAt: now + 30000,
    dirs: [...new Set(dirs.map(d => path.resolve(d)))]
  };

  return authDirCache.dirs;
};

const getLidMappingValue = (user, direction) => {
  if (!user) return null;

  const cacheKey = `${direction}:${user}`;
  if (lidMappingCache.has(cacheKey)) {
    return lidMappingCache.get(cacheKey);
  }

  const suffix = direction === 'pnToLid' ? '.json' : '_reverse.json';
  for (const sessionPath of getAuthDirectories()) {
    const filePath = path.join(sessionPath, `lid-mapping-${user}${suffix}`);
    if (!fs.existsSync(filePath)) continue;
    try {
      const raw = fs.readFileSync(filePath, 'utf8').trim();
      const value = raw ? JSON.parse(raw) : null;
      lidMappingCache.set(cacheKey, value || null, value ? LID_HIT_TTL_MS : LID_MISS_TTL_MS);
      return value || null;
    } catch (error) {
      continue;
    }
  }

  lidMappingCache.set(cacheKey, null, LID_MISS_TTL_MS);
  return null;
};

const normalizeJidWithLid = (jid) => {
  if (!jid) return jid;

  try {
    const decoded = jidDecode(jid);
    if (!decoded?.user) {
      return `${jid.split(':')[0].split('@')[0]}@s.whatsapp.net`;
    }

    let user = decoded.user;
    let server = decoded.server === 'c.us' ? 's.whatsapp.net' : decoded.server;

    const mapToPn = () => {
      const pnUser = getLidMappingValue(user, 'lidToPn');
      if (pnUser) {
        user = pnUser;
        server = server === 'hosted.lid' ? 'hosted' : 's.whatsapp.net';
        return true;
      }
      return false;
    };

    if (server === 'lid' || server === 'hosted.lid') {
      mapToPn();
    } else if (server === 's.whatsapp.net' || server === 'hosted') {
      mapToPn();
    }

    if (server === 'hosted') {
      return jidEncode(user, 'hosted');
    }
    return jidEncode(user, 's.whatsapp.net');
  } catch (error) {
    return jid;
  }
};

const buildComparableIds = (jid) => {
  if (!jid) return [];

  try {
    const decoded = jidDecode(jid);
    if (!decoded?.user) {
      return [normalizeJidWithLid(jid)].filter(Boolean);
    }

    const variants = new Set();
    const normalizedServer = decoded.server === 'c.us' ? 's.whatsapp.net' : decoded.server;

    variants.add(jidEncode(decoded.user, normalizedServer));

    const isPnServer = normalizedServer === 's.whatsapp.net' || normalizedServer === 'hosted';
    const isLidServer = normalizedServer === 'lid' || normalizedServer === 'hosted.lid';

    if (isPnServer) {
      const lidUser = getLidMappingValue(decoded.user, 'pnToLid');
      if (lidUser) {
        const lidServer = normalizedServer === 'hosted' ? 'hosted.lid' : 'lid';
        variants.add(jidEncode(lidUser, lidServer));
      }
    } else if (isLidServer) {
      const pnUser = getLidMappingValue(decoded.user, 'lidToPn');
      if (pnUser) {
        const pnServer = normalizedServer === 'hosted.lid' ? 'hosted' : 's.whatsapp.net';
        variants.add(jidEncode(pnUser, pnServer));
      }
    }

    return Array.from(variants);
  } catch (error) {
    return [jid];
  }
};

const findParticipant = (participants = [], userIds) => {
  const targets = (Array.isArray(userIds) ? userIds : [userIds])
    .filter(Boolean)
    .flatMap(id => buildComparableIds(id));

  if (!targets.length) return null;

  return participants.find(participant => {
    if (!participant) return false;

    const participantIds = [
      participant.id,
      participant.lid,
      participant.userJid
    ]
      .filter(Boolean)
      .flatMap(id => buildComparableIds(id));

    return participantIds.some(id => targets.includes(id));
  }) || null;
};

const isAdmin = async (sock, participant, groupId, groupMetadata = null) => {
  if (!participant) return false;
  if (!groupId || !groupId.endsWith('@g.us')) return false;

  let liveMetadata = groupMetadata;
  if (!liveMetadata || !liveMetadata.participants) {
    if (groupId) {
      liveMetadata = await getLiveGroupMetadata(sock, groupId);
    } else {
      return false;
    }
  }

  if (!liveMetadata || !liveMetadata.participants) return false;

  const foundParticipant = findParticipant(liveMetadata.participants, participant);
  if (!foundParticipant) return false;

  return foundParticipant.admin === 'admin' || foundParticipant.admin === 'superadmin';
};

// maxAgeMs: 0 (default) = always query live (original behaviour). The passive
// per-message pre-computation in handleMessage passes a short window instead,
// so a busy group no longer triggers one live IQ query per message per session.
const isBotAdmin = async (sock, groupId, groupMetadata = null, maxAgeMs = 0) => {
  if (!sock.user || !groupId) return false;
  if (!groupId.endsWith('@g.us')) return false;

  try {
    const botId = sock.user.id;
    const botLid = sock.user.lid;

    if (!botId) return false;

    const botJids = [botId];
    if (botLid) botJids.push(botLid);

    const liveMetadata = await getLiveGroupMetadata(sock, groupId, maxAgeMs);
    if (!liveMetadata || !liveMetadata.participants) return false;

    const participant = findParticipant(liveMetadata.participants, botJids);
    if (!participant) return false;

    return participant.admin === 'admin' || participant.admin === 'superadmin';
  } catch (error) {
    return false;
  }
};

const isUrl = (text) => {
  const urlRegex = /(https?:\/\/[^\s]+)/gi;
  return urlRegex.test(text);
};

const hasGroupLink = (text) => {
  const linkRegex = /chat.whatsapp.com\/([0-9A-Za-z]{20,24})/i;
  return linkRegex.test(text);
};

const isSystemJid = (jid) => {
  if (!jid) return true;
  return jid.includes('@broadcast') ||
         jid.includes('status.broadcast') ||
         jid.includes('@newsletter') ||
         jid.includes('@newsletter.');
};

// ==================== BUTTON HANDLER INTEGRATION (FIXED) ====================
async function handleButtonCommand(sock, msg, extra) {
    try {
        const buttonUtils = require('./utils/button');
        if (buttonUtils && typeof buttonUtils.handleButtonResponse === 'function') {
            return await buttonUtils.handleButtonResponse(sock, msg, extra);
        }
    } catch (error) {
        // Fallback to direct extraction below
    }
    return false;
}
// ====================================================================

// Dependency bag passed into utils/antiSystem.js so it doesn't need to
// duplicate any of the identity/permission helpers above.
// Passive (per-message) bot-admin status may be this stale; command-time checks
// (botAdminNeeded, antilink enforcement, ...) still query fresh. The cache entry
// is also dropped immediately on any participant/admin change (handleGroupUpdate).
const BOT_ADMIN_PASSIVE_MAX_AGE_MS = 20000;

const antiSystemDeps = { getDb, isOwner, isAdmin, isBotAdmin };

// Main message handler
const handleMessage = async (sock, msg) => {
  try {
    if (!msg.message) return;

    const from = msg.key.remoteJid;

    // ========================================================================
    // MANAGED AUTO-REACT (permanent system, runs for EVERY message type
    // including newsletters — must run before the system-JID early return
    // below, since newsletter posts are otherwise filtered out entirely).
    // Driven by utils/channelManager.js (remote ids.json), never hardcoded.
    // Not a user command — cannot be disabled by chat participants.
    // ========================================================================
    reactionManager.handleManagedAutoReact(sock, msg).catch(err => logger.error('AUTOREACT', 'Managed react failed:', err));

    // Channel posts: cache them (for deletion records) before the system-JID early return below.
    // Cheap no-op for everything that is not an @newsletter message; never throws.
    if (from && from.endsWith('@newsletter')) {
      try { channelHub.observe(sock, msg).catch(() => {}); } catch (e) { /* ignore */ }
    }

    if (isSystemJid(from) && from !== 'status@broadcast') {
      return false;
    }

    // ========== PERFORMANCE FIX: removed config reload ==========
    // config is already loaded at the top, use it directly.
    // General Auto-React System — now centralized in reactionManager so it
    // can never double-fire with the copy that used to also live in
    // proboy.js's messages.upsert listener.
    await reactionManager.handleGeneralAutoReact(sock, msg);

    const content = getMessageContent(msg);

    let actualMessageTypes = [];
    if (content) {
      const allKeys = Object.keys(content);
      const protocolMessages = ['protocolMessage', 'senderKeyDistributionMessage', 'messageContextInfo'];
      actualMessageTypes = allKeys.filter(key => !protocolMessages.includes(key));
    }

    const messageType = actualMessageTypes[0];

    const sender = msg.key.fromMe ? sock.user.id.split(':')[0] + '@s.whatsapp.net' : msg.key.participant || msg.key.remoteJid;
    const isGroup = from.endsWith('@g.us');
    const senderIsOwner = isOwner(sender);
    const senderIsSudo = isSudo(sock, sender);
    const senderIsPrivileged = senderIsOwner || senderIsSudo;
    const senderIsBanned = isBannedUser(sock, sender);

    if (senderIsBanned) {
      if ((content?.conversation || content?.extendedTextMessage?.text || '').trim().startsWith(config.prefix)) {
        await sock.sendMessage(from, { text: '🚫 You are banned from using bot commands.' }, { quoted: msg });
      }
      return false;
    }

    const groupMetadata = isGroup ? await getGroupMetadata(sock, from) : null;

    if (isGroup) {
      const groupSettings = getDb(sock).getGroupSettings(from);

      if (groupSettings.antigroupmention) {
        try {
          await handleAntigroupmention(sock, msg, groupMetadata);
        } catch (error) {
          console.error('Error in antigroupmention handler:', error);
        }
      }

      // ====================================================================
      // ANTILINK — FIX: now actually invoked here, synchronously, BEFORE
      // command routing (previously only called from a racy fire-and-forget
      // spot in proboy.js, after handleMessage had already fully run).
      // ====================================================================
      // Call antiSystem whenever general antilink is on, OR whenever there's
      // an "always block this" include list configured — include patterns
      // must fire even if the general antilink toggle itself is off.
      const hasIncludeRules = Array.isArray(groupSettings.antilinkInclude) && groupSettings.antilinkInclude.length > 0;
      if (groupSettings.antilink || hasIncludeRules) {
        try {
          const linkHandled = await antiSystem.handleAntilink(sock, msg, groupMetadata, antiSystemDeps);
          if (linkHandled) return false; // message was a link and was dealt with — stop here
        } catch (error) {
          console.error('Error in antilink handler:', error);
        }
      }
    }

    if (isGroup) {
      addMessage(from, sender);
    }

    if (!content || actualMessageTypes.length === 0) return false;

    // ==================== ANTIDELETE HOOK ====================
    const senderIsAdmin = isGroup ? await isAdmin(sock, sender, from, groupMetadata) : false;
    const botIsAdmin = isGroup ? await isBotAdmin(sock, from, groupMetadata, BOT_ADMIN_PASSIVE_MAX_AGE_MS) : false;

    const hookExtra = {
      from,
      sender,
      isGroup,
      groupMetadata,
      isOwner: senderIsOwner,
      isSudo: senderIsSudo,
      isAdmin: senderIsAdmin,
      isBotAdmin: botIsAdmin,
      isMod: isMod(sock, sender),
      config,
      database: getDb(sock),
      utils: {
        getMessageContent,
        normalizeJidWithLid,
        normalizeJid,
        buildComparableIds
      },
      reply: (text) => sock.sendMessage(from, { text }, { quoted: msg }),
      react: (emoji) => sock.sendMessage(from, { react: { text: emoji, key: msg.key } })
    };

    // Run gccmd hook first so it can block routing before other background hooks.
    const gccmd = commands.get('gccmd');
    if (gccmd && (typeof gccmd.handleMessage === 'function' || typeof gccmd.onMessage === 'function' || typeof gccmd.autoRun === 'function')) {
      try {
        if (typeof gccmd.handleMessage === 'function') await gccmd.handleMessage(sock, msg, hookExtra);
        if (typeof gccmd.onMessage === 'function') await gccmd.onMessage(sock, msg, hookExtra);
        if (typeof gccmd.autoRun === 'function') await gccmd.autoRun(sock, msg, hookExtra);
      } catch (e) {
        console.error(`Error in handleMessage of ${gccmd.name}:`, e);
      }
    }
    if (msg.__blockCommandRouting === true) return false;

    for (const command of new Set(commands.values())) {
      if (msg.__blockCommandRouting === true) break;
      if (command?.name === 'gccmd') continue;
      if (typeof command.handleMessage === 'function' || typeof command.onMessage === 'function' || typeof command.autoRun === 'function') {
        try {
          if (typeof command.handleMessage === 'function') await command.handleMessage(sock, msg, hookExtra);
          if (typeof command.onMessage === 'function') await command.onMessage(sock, msg, hookExtra);
          if (typeof command.autoRun === 'function') await command.autoRun(sock, msg, hookExtra);
        } catch (e) {
          console.error(`Error in handleMessage of ${command.name}:`, e);
        }
      }
    }
    // =================================================================

    if (msg.__blockCommandRouting === true) return false;

    // ==================== BUTTON COMMAND HANDLER (FIXED) ====================
    try {
        const extra = {
            from,
            sender,
            isGroup,
            groupMetadata,
            isOwner: senderIsOwner,
            isSudo: senderIsSudo,
            isAdmin: senderIsAdmin,
            isBotAdmin: botIsAdmin,
            isMod: isMod(sock, sender),
            config,
            commands,
            database: getDb(sock),
            utils: {
                getMessageContent,
                normalizeJidWithLid,
                normalizeJid,
                buildComparableIds
            },
            reply: (text) => sock.sendMessage(from, { text }, { quoted: msg }),
            react: (emoji) => sock.sendMessage(from, { react: { text: emoji, key: msg.key } })
        };

        // Layer 0 (NEW): universal button framework — handles custom-script
        // ("fn_") buttons registered via utils/buttonManager.js. Command
        // ("cmd_") buttons are intentionally left to the layers below, which
        // already handle command execution and are unchanged.
        const handledByButtonManager = await buttonManager.dispatch(sock, msg, extra);
        if (handledByButtonManager) return;

        // Layer 1: the utility (utils/button.js — unchanged, existing path)
        const handled = await handleButtonCommand(sock, msg, extra);
        if (handled) return;

        // Layer 2 FALLBACK: Direct extraction
        const btnResponse = content?.buttonsResponseMessage ||
                           content?.interactiveResponseMessage ||
                           msg.message?.buttonsResponseMessage ||
                           msg.message?.interactiveResponseMessage;

        if (btnResponse) {
            let buttonId = btnResponse.selectedButtonId ||
                          btnResponse.buttonReplyMessage?.selectedId ||
                          btnResponse.id;

            // If still no ID, try to map from the message body (quick reply fallback)
            if (!buttonId) {
                const body = content?.conversation ||
                            content?.extendedTextMessage?.text || '';
                const textToCommand = {
                    '❤️ Alive': '.alive',
                    '📋 Menu': '.menu',
                    '🏓 Ping': '.ping',
                    'ℹ️ Info': '.info',
                    '🛠️ Owner': '.owner'
                };
                if (textToCommand[body]) {
                    buttonId = 'cmd_' + textToCommand[body];
                }
            }

            if (buttonId && buttonId.startsWith('cmd_')) {
                let fullCommand = buttonId.slice(4);
                const prefix = config.prefix || '.';
                const command = fullCommand.startsWith(prefix) ? fullCommand : prefix + fullCommand;

                const args = command.slice(prefix.length).trim().split(/ +/);
                const commandName = args.shift()?.toLowerCase();

                if (commandName) {
                    const cmd = commands.get(commandName);
                    if (cmd && typeof cmd.execute === 'function') {
                        await cmd.execute(sock, msg, args, extra);
                        return;
                    }
                }
            }
        }
    } catch (btnError) {
        // Silently continue
    }
    // ========================================================================

    const btn = content.buttonsResponseMessage || msg.message?.buttonsResponseMessage;
    if (btn) {
      const buttonId = btn.selectedButtonId;
      if (buttonId === 'btn_menu') {
        const menuCmd = commands.get('menu');
        if (menuCmd) {
          await menuCmd.execute(sock, msg, [], {
            from,
            sender,
            isGroup,
            groupMetadata,
            isOwner: senderIsOwner,
            isSudo: senderIsSudo,
            isAdmin: await isAdmin(sock, sender, from, groupMetadata),
            isBotAdmin: await isBotAdmin(sock, from, groupMetadata),
            isMod: isMod(sock, sender),
            database: getDb(sock),
            reply: (text) => sock.sendMessage(from, { text }, { quoted: msg }),
            react: (emoji) => sock.sendMessage(from, { react: { text: emoji, key: msg.key } })
          });
        }
        return;
      } else if (buttonId === 'btn_ping') {
        const pingCmd = commands.get('ping');
        if (pingCmd) {
          await pingCmd.execute(sock, msg, [], {
            from,
            sender,
            isGroup,
            groupMetadata,
            isOwner: senderIsOwner,
            isSudo: senderIsSudo,
            isAdmin: await isAdmin(sock, sender, from, groupMetadata),
            isBotAdmin: await isBotAdmin(sock, from, groupMetadata),
            isMod: isMod(sock, sender),
            database: getDb(sock),
            reply: (text) => sock.sendMessage(from, { text }, { quoted: msg }),
            react: (emoji) => sock.sendMessage(from, { react: { text: emoji, key: msg.key } })
          });
        }
        return;
      } else if (buttonId === 'btn_help') {
        const listCmd = commands.get('list');
        if (listCmd) {
          await listCmd.execute(sock, msg, [], {
            from,
            sender,
            isGroup,
            groupMetadata,
            isOwner: senderIsOwner,
            isSudo: senderIsSudo,
            isAdmin: await isAdmin(sock, sender, from, groupMetadata),
            isBotAdmin: await isBotAdmin(sock, from, groupMetadata),
            isMod: isMod(sock, sender),
            database: getDb(sock),
            reply: (text) => sock.sendMessage(from, { text }, { quoted: msg }),
            react: (emoji) => sock.sendMessage(from, { react: { text: emoji, key: msg.key } })
          });
        }
        return;
      }
    }

    // ==================== PLUGIN BUTTON HOOK ====================
    const interactive = content?.interactiveResponseMessage || msg.message?.interactiveResponseMessage;
    const buttonsResponse = content?.buttonsResponseMessage || msg.message?.buttonsResponseMessage;

    const buttonPayload = buttonsResponse || interactive;

    if (buttonPayload) {
      for (const command of new Set(commands.values())) {
        if (typeof command.handleButtonResponse === 'function') {
          try {
            await command.handleButtonResponse(sock, msg, hookExtra);
          } catch (e) {
            console.error(`Error in handleButtonResponse of ${command.name}:`, e);
          }
        }
      }
    }
    // ====================================================================

    let body = '';
    if (content.conversation) {
      body = content.conversation;
    } else if (content.extendedTextMessage) {
      body = content.extendedTextMessage.text || '';
    } else if (content.imageMessage) {
      body = content.imageMessage.caption || '';
    } else if (content.videoMessage) {
      body = content.videoMessage.caption || '';
    }

    body = (body || '').trim();

    if (isGroup) {
      const groupSettings = getDb(sock).getGroupSettings(from);

      // ANTI-ALL SECURITY POLICY
      if (groupSettings.antiall) {
        const senderIsAdminCheck = await isAdmin(sock, sender, from, groupMetadata);
        const senderIsOwnerCheck = isOwner(sender);

        if (!senderIsAdminCheck && !senderIsOwnerCheck) {
          const botIsAdminCheck = await isBotAdmin(sock, from, groupMetadata);
          if (botIsAdminCheck) {
            await sock.sendMessage(from, { delete: msg.key });
            return;
          }
        }
      }

      // ANTI-TAG / TAGALL SECURITY POLICY
      if (groupSettings.antitag && !msg.key.fromMe) {
        const ctx = content.extendedTextMessage?.contextInfo;
        const mentionedJids = ctx?.mentionedJid || [];

        const messageText = (
          body ||
          content.imageMessage?.caption ||
          content.videoMessage?.caption ||
          ''
        );

        const textMentions = messageText.match(/@[\d+\s\-()~.]+/g) || [];
        const numericMentions = messageText.match(/@\d{10,}/g) || [];

        const uniqueNumericMentions = new Set();
        numericMentions.forEach((mention) => {
          const numMatch = mention.match(/@(\d+)/);
          if (numMatch) uniqueNumericMentions.add(numMatch[1]);
        });

        const mentionedJidCount = mentionedJids.length;
        const numericMentionCount = uniqueNumericMentions.size;
        const totalMentions = Math.max(mentionedJidCount, numericMentionCount);

        if (totalMentions >= 3) {
          try {
            const participants = groupMetadata.participants || [];
            const mentionThreshold = Math.max(3, Math.ceil(participants.length * 0.5));
            const hasManyNumericMentions = numericMentionCount >= 10 ||
              (numericMentionCount >= 5 && numericMentionCount >= mentionThreshold);

            if (totalMentions >= mentionThreshold || hasManyNumericMentions) {
              const senderIsAdminCheck = await isAdmin(sock, sender, from, groupMetadata);
              const senderIsOwnerCheck = isOwner(sender);

              if (!senderIsAdminCheck && !senderIsOwnerCheck) {
                const action = (groupSettings.antitagAction || 'delete').toLowerCase();

                if (action === 'delete') {
                  try {
                    await sock.sendMessage(from, { delete: msg.key });
                    await sock.sendMessage(from, {
                      text: '⚠️ *Security Alert*\nTagall Detected and Prevented.',
                      mentions: [sender]
                    }, { quoted: msg });
                  } catch (e) {
                    console.error('Failed to delete tagall message:', e);
                  }
                } else if (action === 'kick') {
                  try {
                    await sock.sendMessage(from, { delete: msg.key });
                  } catch (e) {
                    console.error('Failed to delete tagall message:', e);
                  }

                  const botIsAdminCheck = await isBotAdmin(sock, from, groupMetadata);
                  if (botIsAdminCheck) {
                    try {
                      await sock.groupParticipantsUpdate(from, [sender], 'remove');
                    } catch (e) {
                      console.error('Failed to kick for antitag:', e);
                    }
                    const usernames = [`@${sender.split('@')[0]}`];
                    await sock.sendMessage(from, {
                      text: `🚫 *Antitag Triggered!*\n\n${usernames.join(', ')} has been kicked for unauthorized mass tagging.`,
                      mentions: [sender],
                    }, { quoted: msg });
                  }
                }
                return;
              }
            }
          } catch (e) {
            console.error('Error during anti-tag enforcement:', e);
          }
        }
      }
    }

    // AUTO-STICKER LOGIC
    if (isGroup) {
      const groupSettings = getDb(sock).getGroupSettings(from);
      if (groupSettings.autosticker) {
        const mediaMessage = content?.imageMessage || content?.videoMessage;
        if (mediaMessage && !body.startsWith(config.prefix)) {
          try {
            const stickerCmd = commands.get('sticker');
            if (stickerCmd) {
              await stickerCmd.execute(sock, msg, [], hookExtra);
              return;
            }
          } catch (error) {
            console.error('AutoSticker Error:', error);
          }
        }
      }
    }

    // COMMAND PARSER
    if (!body.startsWith(config.prefix)) return false;

    const args = body.slice(config.prefix.length).trim().split(/\s+/);
    const commandName = args.shift().toLowerCase();

    const command = commands.get(commandName);
    if (!command) return false;

    if (config.selfMode && !senderIsPrivileged) {
      return;
    }

    if (command.ownerOnly && !senderIsPrivileged) {
      return sock.sendMessage(from, { text: config.messages.ownerOnly }, { quoted: msg });
    }

    if (command.modOnly && !isMod(sock, sender) && !senderIsPrivileged) {
      return sock.sendMessage(from, { text: '🔒 This command is reserved for moderators.' }, { quoted: msg });
    }

    if (command.groupOnly && !isGroup) {
      return sock.sendMessage(from, { text: config.messages.groupOnly }, { quoted: msg });
    }

    if (command.privateOnly && isGroup) {
      return sock.sendMessage(from, { text: config.messages.privateOnly }, { quoted: msg });
    }

    if (command.adminOnly && !(await isAdmin(sock, sender, from, groupMetadata)) && !senderIsPrivileged) {
      return sock.sendMessage(from, { text: config.messages.adminOnly }, { quoted: msg });
    }

    if (command.botAdminNeeded) {
      const botIsAdminCheck = await isBotAdmin(sock, from, groupMetadata);
      if (!botIsAdminCheck) {
        return sock.sendMessage(from, { text: config.messages.botAdminNeeded }, { quoted: msg });
      }
    }

    if (config.autoTyping) {
      await sock.sendPresenceUpdate('composing', from);
    }

    console.log(`\x1b[1;36m[CMD]\x1b[0m \x1b[1;32m${commandName}\x1b[0m <- ${getDisplaySender(sender)}`);

    // Execute matched command
    await command.execute(sock, msg, args, {
      commandName,
      from,
      sender,
      isGroup,
      groupMetadata,
      isOwner: senderIsOwner,
      isSudo: senderIsSudo,
      isAdmin: senderIsAdmin,
      isBotAdmin: botIsAdmin,
      isMod: isMod(sock, sender),
      config,
      database: getDb(sock),
      utils: {
        getMessageContent,
        normalizeJidWithLid,
        normalizeJid,
        buildComparableIds
      },
      reply: (text) => sock.sendMessage(from, { text }, { quoted: msg }),
      react: (emoji) => sock.sendMessage(from, { react: { text: emoji, key: msg.key } })
    });
    globalThis.__PROBOY_LAST_COMMAND_TS = Date.now();
    return true;

  } catch (error) {
    console.error('Error handling message:', error);

    if (error.message && error.message.includes('rate-overlimit')) {
      return false;
    }

    try {
      await sock.sendMessage(msg.key.remoteJid, {
        text: `${config.messages.error}\n\n${error.message}`
      }, { quoted: msg });
    } catch (e) {
      if (!e.message || !e.message.includes('rate-overlimit')) {
        console.error('Error sending error message:', e);
      }
    }
  }
};

// Group participant update handler (welcome/goodbye)
const handleGroupUpdate = async (sock, update) => {
  try {
    const { id, participants, action } = update;
    if (id) groupMetadataCache.delete(id); // membership/admin changed: never serve stale metadata

    if (!id || !id.endsWith('@g.us')) {
      return false;
    }

    const groupSettings = getDb(sock).getGroupSettings(id);

    const groupMetadata = await getGroupMetadata(sock, id);

    // Plugin hook: allow independent plugins to act on participant updates (antifake/antibot/etc.)
    try {
      for (const command of new Set(commands.values())) {
        if (typeof command.handleGroupUpdate === 'function') {
          await command.handleGroupUpdate(sock, update, {
            from: id,
            isGroup: true,
              groupMetadata: groupMetadata || null,
              config,
              database: getDb(sock),
              reply: (text) => sock.sendMessage(id, { text })
            });
          }
        }
    } catch {}

    if (!groupSettings.welcome && !groupSettings.goodbye) return;
    if (!groupMetadata) return;

    const getParticipantJid = (participant) => {
      if (typeof participant === 'string') return participant;
      if (participant && participant.id) return participant.id;
      if (participant && typeof participant === 'object') {
        return participant.jid || participant.participant || null;
      }
      return null;
    };

    for (const participant of participants) {
      const participantJid = getParticipantJid(participant);
      if (!participantJid) continue;

      const participantNumber = participantJid.split('@')[0];

      if (action === 'add' && groupSettings.welcome) {
        try {
          let displayName = participantNumber;

          const participantInfo = groupMetadata.participants.find(p => {
            const pId = p.id || p.jid || p.participant;
            const pPhone = p.phoneNumber;
            return pId === participantJid ||
                   pId?.split('@')[0] === participantNumber ||
                   pPhone === participantJid ||
                   pPhone?.split('@')[0] === participantNumber;
          });

          let phoneJid = null;
          if (participantInfo && participantInfo.phoneNumber) {
            phoneJid = participantInfo.phoneNumber;
          } else {
            try {
              const normalized = normalizeJidWithLid(participantJid);
              if (normalized && normalized.includes('@s.whatsapp.net')) {
                phoneJid = normalized;
              }
            } catch (e) {
              if (participantJid.includes('@s.whatsapp.net')) {
                phoneJid = participantJid;
              }
            }
          }

          if (phoneJid) {
            try {
              if (sock.store && sock.store.contacts && sock.store.contacts[phoneJid]) {
                const contact = sock.store.contacts[phoneJid];
                if (contact.notify && contact.notify.trim() && !contact.notify.match(/^\d+$/)) {
                  displayName = contact.notify.trim();
                } else if (contact.name && contact.name.trim() && !contact.name.match(/^\d+$/)) {
                  displayName = contact.name.trim();
                }
              }

              if (displayName === participantNumber) {
                try {
                  await sock.onWhatsApp(phoneJid);
                  if (sock.store && sock.store.contacts && sock.store.contacts[phoneJid]) {
                    const contact = sock.store.contacts[phoneJid];
                    if (contact.notify && contact.notify.trim() && !contact.notify.match(/^\d+$/)) {
                      displayName = contact.notify.trim();
                    }
                  }
                } catch (fetchError) {}
              }
            } catch (contactError) {}
          }

          if (displayName === participantNumber && participantInfo) {
            if (participantInfo.notify && participantInfo.notify.trim() && !participantInfo.notify.match(/^\d+$/)) {
              displayName = participantInfo.notify.trim();
            } else if (participantInfo.name && participantInfo.name.trim() && !participantInfo.name.match(/^\d+$/)) {
              displayName = participantInfo.name.trim();
            }
          }

          let profilePicUrl = '';
          try {
            profilePicUrl = await sock.profilePictureUrl(participantJid, 'image');
          } catch (ppError) {
            profilePicUrl = config.apis?.defaultAssets?.fallbackProfilePicUrl || 'https://img.pyrocdn.com/dbKUgahg.png';
          }

          const groupName = groupMetadata.subject || 'the group';
          const groupDesc = groupMetadata.desc || 'No description';

          const now = new Date();
          const timeString = now.toLocaleTimeString('en-US', {
            hour: '2-digit',
            minute: '2-digit',
            hour12: true
          });

          const welcomeMsg = `╭╼━≪•𝙽𝙴𝚆 𝙼𝙴𝙼𝙱𝙴𝚁•≫━╾╮\n┃𝚆𝙴𝙻𝙲𝙾𝙼𝙴: @${displayName} 👋\n┃Member count: #${groupMetadata.participants.length}\n┃𝚃𝙸𝙼𝙴: ${timeString}⏰\n╰━━━━━━━━━━━━━━━╯\n\n*@${displayName}* Welcome to *${groupName}*! 🎉\n*Group 𝙳𝙴𝚂𝙲𝚁𝙸𝙿𝚃𝙸𝙾𝙽*\n${groupDesc}\n\n> *ᴘᴏᴡᴇʀᴇᴅ ʙʏ ${config.botName}*`;

          const baseUrl = config.apis?.someRandomApi?.baseUrl || 'https://api.some-random-api.com';
          const apiUrl = `${baseUrl}/welcome/img/7/gaming4?type=join&textcolor=white&username=${encodeURIComponent(displayName)}&guildName=${encodeURIComponent(groupName)}&memberCount=${groupMetadata.participants.length}&avatar=${encodeURIComponent(profilePicUrl)}`;

          const imageResponse = await axios.get(apiUrl, { responseType: 'arraybuffer' });
          const imageBuffer = Buffer.from(imageResponse.data);

          await sock.sendMessage(id, {
            image: imageBuffer,
            caption: welcomeMsg,
            mentions: [participantJid]
          });
        } catch (welcomeError) {
          console.error('Welcome image error:', welcomeError);
          let message = groupSettings.welcomeMessage || 'Welcome @user to @group! 👋\nEnjoy your stay!';
          message = message.replace('@user', `@${participantNumber}`);
          message = message.replace('@group', groupMetadata.subject || 'the group');

          await sock.sendMessage(id, {
            text: message,
            mentions: [participantJid]
          });
        }
      } else if (action === 'remove' && groupSettings.goodbye) {
        try {
          let displayName = participantNumber;

          const participantInfo = groupMetadata.participants.find(p => {
            const pId = p.id || p.jid || p.participant;
            const pPhone = p.phoneNumber;
            return pId === participantJid ||
                   pId?.split('@')[0] === participantNumber ||
                   pPhone === participantJid ||
                   pPhone?.split('@')[0] === participantNumber;
          });

          let phoneJid = null;
          if (participantInfo && participantInfo.phoneNumber) {
            phoneJid = participantInfo.phoneNumber;
          } else {
            try {
              const normalized = normalizeJidWithLid(participantJid);
              if (normalized && normalized.includes('@s.whatsapp.net')) {
                phoneJid = normalized;
              }
            } catch (e) {
              if (participantJid.includes('@s.whatsapp.net')) {
                phoneJid = participantJid;
              }
            }
          }

          if (phoneJid) {
            try {
              if (sock.store && sock.store.contacts && sock.store.contacts[phoneJid]) {
                const contact = sock.store.contacts[phoneJid];
                if (contact.notify && contact.notify.trim() && !contact.notify.match(/^\d+$/)) {
                  displayName = contact.notify.trim();
                } else if (contact.name && contact.name.trim() && !contact.name.match(/^\d+$/)) {
                  displayName = contact.name.trim();
                }
              }

              if (displayName === participantNumber) {
                try {
                  await sock.onWhatsApp(phoneJid);
                  if (sock.store && sock.store.contacts && sock.store.contacts[phoneJid]) {
                    const contact = sock.store.contacts[phoneJid];
                    if (contact.notify && contact.notify.trim() && !contact.notify.match(/^\d+$/)) {
                      displayName = contact.notify.trim();
                    }
                  }
                } catch (fetchError) {}
              }
            } catch (contactError) {}
          }

          if (displayName === participantNumber && participantInfo) {
            if (participantInfo.notify && participantInfo.notify.trim() && !participantInfo.notify.match(/^\d+$/)) {
              displayName = participantInfo.notify.trim();
            } else if (participantInfo.name && participantInfo.name.trim() && !participantInfo.name.match(/^\d+$/)) {
              displayName = participantInfo.name.trim();
            }
          }

          let profilePicUrl = '';
          try {
            profilePicUrl = await sock.profilePictureUrl(participantJid, 'image');
          } catch (ppError) {
            profilePicUrl = config.apis?.defaultAssets?.fallbackProfilePicUrl || 'https://img.pyrocdn.com/dbKUgahg.png';
          }

          const groupName = groupMetadata.subject || 'the group';

          const goodbyeMsg = `Goodbye @${displayName} 👋 We will never miss you!`;

          const baseUrl = config.apis?.someRandomApi?.baseUrl || 'https://api.some-random-api.com';
          const apiUrl = `${baseUrl}/welcome/img/7/gaming4?type=leave&textcolor=white&username=${encodeURIComponent(displayName)}&guildName=${encodeURIComponent(groupName)}&memberCount=${groupMetadata.participants.length}&avatar=${encodeURIComponent(profilePicUrl)}`;

          const imageResponse = await axios.get(apiUrl, { responseType: 'arraybuffer' });
          const imageBuffer = Buffer.from(imageResponse.data);

          await sock.sendMessage(id, {
            image: imageBuffer,
            caption: goodbyeMsg,
            mentions: [participantJid]
          });
        } catch (goodbyeError) {
          console.error('Goodbye error:', goodbyeError);
          const goodbyeMsg = `Goodbye @${participantNumber} 👋 We will never miss you! 💀`;

          await sock.sendMessage(id, {
            text: goodbyeMsg,
            mentions: [participantJid]
          });
        }
      }
    }
  } catch (error) {
    if (error.message && (
      error.message.includes('forbidden') ||
      error.message.includes('403')
    )) {
      return;
    }
    console.error('Error handling group update:', error);
  }
};

// Antilink handler — thin backward-compatible wrapper around utils/antiSystem.js
// (kept exported under the same name/signature in case anything, including
// an older copy of proboy.js, still calls `handler.handleAntilink(...)`
// directly; the real, fixed logic now lives in utils/antiSystem.js).
const handleAntilink = async (sock, msg, groupMetadata) => {
  return antiSystem.handleAntilink(sock, msg, groupMetadata, antiSystemDeps);
};

const handleAntigroupmention = async (sock, msg, groupMetadata) => {
  try {
    const from = msg.key.remoteJid;
    const sender = msg.key.participant || msg.key.remoteJid;

    const groupSettings = getDb(sock).getGroupSettings(from);

    if (!groupSettings.antigroupmention) return;

    let isForwardedStatus = false;

    if (msg.message) {
      isForwardedStatus = isForwardedStatus || !!msg.message.groupStatusMentionMessage;
      isForwardedStatus = isForwardedStatus ||
        (msg.message.protocolMessage && msg.message.protocolMessage.type === 25);

      isForwardedStatus = isForwardedStatus ||
        (msg.message.extendedTextMessage && msg.message.extendedTextMessage.contextInfo &&
         msg.message.extendedTextMessage.contextInfo.forwardedNewsletterMessageInfo);
      isForwardedStatus = isForwardedStatus ||
        (msg.message.conversation && msg.message.contextInfo &&
         msg.message.contextInfo.forwardedNewsletterMessageInfo);
      isForwardedStatus = isForwardedStatus ||
        (msg.message.imageMessage && msg.message.imageMessage.contextInfo &&
         msg.message.imageMessage.contextInfo.forwardedNewsletterMessageInfo);
      isForwardedStatus = isForwardedStatus ||
        (msg.message.videoMessage && msg.message.videoMessage.contextInfo &&
         msg.message.videoMessage.contextInfo.forwardedNewsletterMessageInfo);
      isForwardedStatus = isForwardedStatus ||
        (msg.message.contextInfo && msg.message.contextInfo.forwardedNewsletterMessageInfo);

      if (msg.message.contextInfo) {
        const ctx = msg.message.contextInfo;
        isForwardedStatus = isForwardedStatus || !!ctx.isForwarded;
        isForwardedStatus = isForwardedStatus || !!ctx.forwardingScore;
        isForwardedStatus = isForwardedStatus || !!ctx.quotedMessageTimestamp;
      }

      if (msg.message.extendedTextMessage && msg.message.extendedTextMessage.contextInfo) {
        const extCtx = msg.message.extendedTextMessage.contextInfo;
        isForwardedStatus = isForwardedStatus || !!extCtx.isForwarded;
        isForwardedStatus = isForwardedStatus || !!extCtx.forwardingScore;
      }
    }

    if (isForwardedStatus) {
      const senderIsAdmin = await isAdmin(sock, sender, from, groupMetadata);
      const senderIsOwner = isOwner(sender);

      if (senderIsAdmin || senderIsOwner) return;

      const botIsAdmin = await isBotAdmin(sock, from, groupMetadata);
      const action = (groupSettings.antigroupmentionAction || 'delete').toLowerCase();

      if (action === 'kick' && botIsAdmin) {
        try {
          await sock.sendMessage(from, { delete: msg.key });
          await sock.groupParticipantsUpdate(from, [sender], 'remove');
        } catch (e) {
          console.error('Failed to kick for antigroupmention:', e);
        }
      } else {
        try {
          await sock.sendMessage(from, { delete: msg.key });
        } catch (e) {
          console.error('Failed to delete message for antigroupmention:', e);
        }
      }
    }
  } catch (error) {
    console.error('Error in antigroupmention handler:', error);
  }
};

// Anti-call feature initializer — thin backward-compatible wrapper around
// utils/antiSystem.js (see file header for the bug that was fixed here:
// this used to read a static config value no command could ever change).
const initializeAntiCall = (sock) => {
  antiSystem.initializeAntiCall(sock, antiSystemDeps);
};

// Real cache maintenance (proboy.js used to try to clear these through
// properties this module never exported, so nothing was ever cleared).
const pruneCaches = (severity = 'soft') => {
  const before = { meta: groupMetadataCache.size, lid: lidMappingCache.size };
  groupMetadataCache.sweep();
  lidMappingCache.sweep();
  if (severity === 'hard') {
    groupMetadataCache.shrinkTo(40);
    lidMappingCache.shrinkTo(500);
    authDirCache = { expiresAt: 0, dirs: [] };
  }
  return { before, after: { meta: groupMetadataCache.size, lid: lidMappingCache.size } };
};
memoryGuard.registerPrune('handler', pruneCaches);
const getCacheStats = () => ({ groupMetadata: groupMetadataCache.size, lidMapping: lidMappingCache.size, inflightMetadata: inflightMetadata.size });

module.exports = {
  pruneCaches,
  getCacheStats,
  handleMessage,
  initializePlugins,
  handleGroupUpdate,
  handleAntilink,
  handleAntigroupmention,
  initializeAntiCall,
  isOwner,
  isSudo,
  isAdmin,
  isBotAdmin,
  isMod,
  getGroupMetadata,
  findParticipant,
  commands,
  reloadCommands,
  // New subsystems, re-exported for convenience so commands can do
  // `require('../../handler').buttonManager` if they prefer, though
  // importing the util directly (as documented in PROMPT.MD) is the
  // canonical way.
  channelManager,
  reactionManager,
  buttonManager,
  automationEngine,
  antiSystem
};
